#ifndef __MODEL_H__
#define __MODEL_H__

enum class CPU_Model {INTEL_i7_12700H, AMD_Ryzen_7_6800H};
enum class MEM_Model {DDR4_3600MHz, DDR4_4000MHz, DDR4_4400MHz};

#endif