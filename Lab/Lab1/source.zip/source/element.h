#ifndef __ELEMENT_H__
#define __ELEMENT_H__

enum Element {NOMRAL = 0, FIRE, ICE, WIND, THUNDER};

#endif